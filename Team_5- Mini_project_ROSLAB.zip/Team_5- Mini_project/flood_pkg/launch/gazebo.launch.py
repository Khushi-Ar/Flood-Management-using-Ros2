import os
from launch import LaunchDescription
from ament_index_python.packages import get_package_share_directory
import xacro

def generate_launch_description():
    # Get the package directory
    pkg_dir = get_package_share_directory('drone_again')

    # URDF file path
    urdf_file = os.path.join(pkg_dir, 'urdf', 'drone_again.urdf')

    # Launch Gazebo
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([os.path.join(
            get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')]),
    )

    # Spawn the robot in Gazebo
    spawn_entity = Node(
        package='gazebo_ros', 
        executable='spawn_entity.py',
        arguments=['-entity', 'drone_again',
        output='screen'
   

    return LaunchDescription([
        gazebo,
        robot_state_publisher,
        spawn_entity,
    ])