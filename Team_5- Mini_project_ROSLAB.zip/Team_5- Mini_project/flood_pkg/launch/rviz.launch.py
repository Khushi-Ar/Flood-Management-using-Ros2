import os
from launch import LaunchDescription
import xacro

def generate_launch_description():
    # Get the package directory
    pkg_dir = get_package_share_directory('drone_again')

    # URDF file path
    urdf_file = os.path.join(pkg_dir, 'urdf', 'drone_again.urdf')

    # Process the URDF file
    doc = xacro.parse(open(urdf_file))
    xacro.process_doc(doc)
   

    # Launch RViz
    rviz_config_file = os.path.join(pkg_dir, 'config', 'drone_again.rviz')
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        output='screen'
    )

    # Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
    )

    # Joint State Publisher (GUI)
    joint_state_publisher_gui = Node(
        package='joint_state_publisher_gui',
       
    )

    return LaunchDescription([
        robot_state_publisher,
        joint_state_publisher_gui,
        rviz
    ])